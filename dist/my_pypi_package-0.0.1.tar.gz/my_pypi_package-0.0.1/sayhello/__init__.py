def dummy():
    print('dummy func!')
